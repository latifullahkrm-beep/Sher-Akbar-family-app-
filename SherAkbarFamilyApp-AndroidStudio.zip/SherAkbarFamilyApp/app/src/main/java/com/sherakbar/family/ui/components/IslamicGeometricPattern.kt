package com.sherakbar.family.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.sherakbar.family.ui.theme.RoyalGold
import kotlin.math.cos
import kotlin.math.sin

/**
 * Draws a subtle Islamic 8-point geometric Girih lattice & Pakistani Mughal arch motif.
 */
@Composable
fun IslamicGeometricBackground(
    modifier: Modifier = Modifier,
    lineColor: Color = RoyalGold.copy(alpha = 0.16f),
    accentColor: Color = RoyalGold.copy(alpha = 0.28f)
) {
    Canvas(modifier = modifier) {
        val tileSize = 56.dp.toPx()
        val cols = (size.width / tileSize).toInt() + 2
        val rows = (size.height / tileSize).toInt() + 2
        val stroke = Stroke(width = 1.dp.toPx())

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val cx = c * tileSize
                val cy = r * tileSize
                val radius = tileSize * 0.36f

                // 8-point Rub el Hizb star
                val path1 = Path()
                val path2 = Path()
                for (i in 0 until 4) {
                    val a1 = Math.toRadians((i * 90 + 45).toDouble())
                    val x1 = cx + radius * cos(a1).toFloat()
                    val y1 = cy + radius * sin(a1).toFloat()
                    if (i == 0) path1.moveTo(x1, y1) else path1.lineTo(x1, y1)

                    val a2 = Math.toRadians((i * 90).toDouble())
                    val x2 = cx + radius * cos(a2).toFloat()
                    val y2 = cy + radius * sin(a2).toFloat()
                    if (i == 0) path2.moveTo(x2, y2) else path2.lineTo(x2, y2)
                }
                path1.close()
                path2.close()
                drawPath(path1, color = lineColor, style = stroke)
                drawPath(path2, color = lineColor, style = stroke)

                // Center medallion dot
                drawCircle(
                    color = accentColor,
                    radius = 2.dp.toPx(),
                    center = Offset(cx, cy)
                )
            }
        }
    }
}

@Composable
fun MughalArchBorder(
    modifier: Modifier = Modifier,
    color: Color = RoyalGold.copy(alpha = 0.45f)
) {
    Canvas(modifier = modifier) {
        val strokeWidth = 1.5.dp.toPx()
        val inset = 6.dp.toPx()
        val w = size.width - inset * 2
        val h = size.height - inset * 2
        val archApexY = inset
        val shoulderY = inset + 26.dp.toPx()

        val path = Path().apply {
            moveTo(inset, size.height - inset)
            lineTo(inset, shoulderY)
            quadraticTo(
                inset + w * 0.25f, archApexY + 10.dp.toPx(),
                inset + w * 0.5f, archApexY
            )
            quadraticTo(
                inset + w * 0.75f, archApexY + 10.dp.toPx(),
                size.width - inset, shoulderY
            )
            lineTo(size.width - inset, size.height - inset)
            close()
        }
        drawPath(path = path, color = color, style = Stroke(width = strokeWidth))
    }
}
