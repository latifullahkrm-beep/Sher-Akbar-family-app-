package com.sherakbar.family.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.ContactMail
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Newspaper
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sherakbar.family.R
import com.sherakbar.family.ui.components.GoldOrnamentalDivider
import com.sherakbar.family.ui.components.SherAkbarCrest
import com.sherakbar.family.ui.theme.CrimsonAlert
import com.sherakbar.family.ui.theme.ForestGreen
import com.sherakbar.family.ui.theme.RoyalGold
import com.sherakbar.family.ui.viewmodel.MainViewModel

@Composable
fun MoreMenuScreen(
    viewModel: MainViewModel,
    onNavigateAnnouncements: () -> Unit,
    onNavigateAdmin: () -> Unit,
    onNavigateAbout: () -> Unit,
    onNavigateContact: () -> Unit,
    onNavigateSettings: () -> Unit,
    onLogout: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val isAdmin by viewModel.isAdmin.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = ForestGreen,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SherAkbarCrest(size = 54.dp)
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                    Text(
                        text = currentUser?.fullName ?: "Sher Akbar Member",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${currentUser?.email.orEmpty()} • ${currentUser?.role?.name ?: "MEMBER"}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = RoyalGold
                    )
                }
            }
        }

        if (isAdmin) {
            MoreMenuRow(
                title = stringResource(R.string.admin_panel),
                subtitle = "Manage members, tree, gallery, approvals & backup",
                icon = Icons.Outlined.AdminPanelSettings,
                onClick = onNavigateAdmin
            )
        }

        MoreMenuRow(
            title = stringResource(R.string.family_news),
            subtitle = "Latest stories, weddings, births & gatherings",
            icon = Icons.Outlined.Newspaper,
            onClick = onNavigateAnnouncements
        )
        MoreMenuRow(
            title = stringResource(R.string.announcements),
            subtitle = "Official notices from family elders",
            icon = Icons.Outlined.Campaign,
            onClick = onNavigateAnnouncements
        )
        MoreMenuRow(
            title = stringResource(R.string.about_family),
            subtitle = "History & heritage of Haji Sher Akbar Khan",
            icon = Icons.Outlined.Info,
            onClick = onNavigateAbout
        )
        MoreMenuRow(
            title = stringResource(R.string.contact_admin),
            subtitle = "Request corrections or reach family council",
            icon = Icons.Outlined.ContactMail,
            onClick = onNavigateContact
        )
        MoreMenuRow(
            title = stringResource(R.string.settings),
            subtitle = "English / Urdu language, Dark Mode & notifications",
            icon = Icons.Outlined.Settings,
            onClick = onNavigateSettings
        )

        Spacer(modifier = Modifier.height(6.dp))
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onLogout),
            shape = RoundedCornerShape(14.dp),
            color = CrimsonAlert.copy(alpha = 0.08f),
            border = BorderStroke(1.dp, CrimsonAlert.copy(alpha = 0.35f))
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.AutoMirrored.Outlined.Logout, contentDescription = null, tint = CrimsonAlert)
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = stringResource(R.string.logout),
                    style = MaterialTheme.typography.titleMedium,
                    color = CrimsonAlert,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun MoreMenuRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = ForestGreen)
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Outlined.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutFamilyScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.about_family)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ForestGreen,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.patriarch_sher_akbar),
                contentDescription = "Haji Sher Akbar Khan",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(140.dp)
                    .clip(CircleShape)
            )
            Text("Haji Sher Akbar Khan", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Founder & Patriarch • Est. 1944", style = MaterialTheme.typography.labelLarge, color = RoyalGold)
            GoldOrnamentalDivider()
            Text(
                text = "Rooted in the historic traditions of Swabi and Khyber Pakhtunkhwa, the Sher Akbar Family upholds honor, hospitality (Melmastia), faith, and lifelong pursuit of knowledge. This official family application preserves our multi-generation lineage, honors our elders, and keeps every branch connected across Pakistan and around the world.",
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactAdminScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.contact_admin)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ForestGreen,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Sher Akbar Family Council", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(
                text = "Need to update family tree records, submit historical photographs, or approve a new family member account? Reach out directly to the family administrator.",
                style = MaterialTheme.typography.bodyLarge
            )
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Administrator: Kashif Kareem Sher Akbar", style = MaterialTheme.typography.titleMedium)
                    Text("Email: admin@sherakbar.family", style = MaterialTheme.typography.bodyMedium)
                    Text("Phone: +92 345 5550301", style = MaterialTheme.typography.bodyMedium)
                    Text("Haveli: Peshawar Road, Swabi, KPK", style = MaterialTheme.typography.bodyMedium)
                }
            }
            Button(
                onClick = {
                    val intent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("mailto:admin@sherakbar.family")
                        putExtra(Intent.EXTRA_SUBJECT, "Sher Akbar Family App Inquiry")
                    }
                    context.startActivity(intent)
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Send Email to Admin")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val darkMode by viewModel.darkMode.collectAsState()
    val languageCode by viewModel.languageCode.collectAsState()
    val notificationsEnabled by viewModel.notificationsEnabled.collectAsState()
    val lastSyncEpoch by viewModel.lastSyncEpoch.collectAsState()

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.setNotificationsEnabled(granted)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ForestGreen,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(stringResource(R.string.dark_mode), style = MaterialTheme.typography.titleMedium)
                    Text("Switch between Off-White and Deep Forest Dark", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = darkMode, onCheckedChange = viewModel::setDarkMode)
            }

            HorizontalDivider()

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(stringResource(R.string.notifications), style = MaterialTheme.typography.titleMedium)
                    Text("Receive family announcement alerts", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(
                    checked = notificationsEnabled,
                    onCheckedChange = { enable ->
                        if (enable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            viewModel.setNotificationsEnabled(enable)
                        }
                    }
                )
            }

            HorizontalDivider()

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.language), style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FilterChip(
                        selected = languageCode == "en",
                        onClick = { viewModel.setLanguage("en") },
                        label = { Text(stringResource(R.string.english)) }
                    )
                    FilterChip(
                        selected = languageCode == "ur",
                        onClick = { viewModel.setLanguage("ur") },
                        label = { Text(stringResource(R.string.urdu)) }
                    )
                }
            }

            HorizontalDivider()

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Offline Storage & Cloud Sync", style = MaterialTheme.typography.titleMedium)
                Text(
                    text = if (lastSyncEpoch == 0L) "Local Room database cached for offline access."
                    else "Last synchronized: ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(lastSyncEpoch))}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(onClick = { viewModel.syncNow() }) {
                    Text("Synchronize Now")
                }
            }
        }
    }
}
