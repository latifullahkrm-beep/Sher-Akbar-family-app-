package com.sherakbar.family.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.sherakbar.family.R
import com.sherakbar.family.ui.components.IslamicGeometricBackground
import com.sherakbar.family.ui.components.SherAkbarCrest
import com.sherakbar.family.ui.theme.ForestGreen
import com.sherakbar.family.ui.theme.ForestGreenDark
import com.sherakbar.family.ui.theme.RoyalGold
import kotlinx.coroutines.delay

@Composable
fun SplashScreenRoute(
    authInitialized: Boolean,
    isLoggedIn: Boolean,
    onFinished: (Boolean) -> Unit
) {
    val scale = remember { Animatable(0.75f) }
    val alpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        scale.animateTo(1f, animationSpec = tween(700, easing = FastOutSlowInEasing))
    }
    LaunchedEffect(Unit) {
        alpha.animateTo(1f, animationSpec = tween(650))
    }
    LaunchedEffect(authInitialized, isLoggedIn) {
        if (authInitialized) {
            delay(1100)
            onFinished(isLoggedIn)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(ForestGreenDark, ForestGreen, ForestGreenDark)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        IslamicGeometricBackground(
            modifier = Modifier.fillMaxSize(),
            lineColor = RoyalGold.copy(alpha = 0.14f),
            accentColor = RoyalGold.copy(alpha = 0.25f)
        )

        Column(
            modifier = Modifier
                .padding(32.dp)
                .scale(scale.value)
                .alpha(alpha.value),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            SherAkbarCrest(size = 124.dp, shieldFill = ForestGreenDark, goldColor = RoyalGold)
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.displaySmall,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "شیر اکبر خاندان • Unity, Heritage & Lineage",
                style = MaterialTheme.typography.bodyMedium,
                color = RoyalGold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(36.dp))
            CircularProgressIndicator(
                modifier = Modifier.size(28.dp),
                color = RoyalGold,
                strokeWidth = 2.5.dp
            )
        }
    }
}
