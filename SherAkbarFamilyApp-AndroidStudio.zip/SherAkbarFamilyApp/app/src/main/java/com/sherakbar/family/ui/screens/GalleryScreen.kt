package com.sherakbar.family.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddAPhoto
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.CreateNewFolder
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.sherakbar.family.data.model.GalleryPhoto
import com.sherakbar.family.ui.components.ConfirmDeleteDialog
import com.sherakbar.family.ui.components.EmptyStateView
import com.sherakbar.family.ui.theme.CrimsonAlert
import com.sherakbar.family.ui.theme.ForestGreen
import com.sherakbar.family.ui.theme.RoyalGold
import com.sherakbar.family.ui.viewmodel.MainViewModel

@Composable
fun GalleryScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val albums by viewModel.albums.collectAsState()
    val photos by viewModel.allPhotos.collectAsState()
    val isAdmin by viewModel.isAdmin.collectAsState()

    var selectedAlbumId by remember { mutableStateOf<String?>(null) }
    var showCreateAlbumDialog by remember { mutableStateOf(false) }
    var pendingPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var fullScreenPhoto by remember { mutableStateOf<GalleryPhoto?>(null) }
    var photoToDelete by remember { mutableStateOf<GalleryPhoto?>(null) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) pendingPhotoUri = uri }

    val visiblePhotos = remember(photos, selectedAlbumId) {
        if (selectedAlbumId == null) photos else photos.filter { it.albumId == selectedAlbumId }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header + Albums Strip
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Family Photo Gallery",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    OutlinedButton(onClick = { showCreateAlbumDialog = true }) {
                        Icon(Icons.Outlined.CreateNewFolder, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("New Album")
                    }
                }

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(
                            selected = selectedAlbumId == null,
                            onClick = { selectedAlbumId = null },
                            label = { Text("All Photos (${photos.size})") }
                        )
                    }
                    items(albums, key = { it.id }) { album ->
                        FilterChip(
                            selected = selectedAlbumId == album.id,
                            onClick = { selectedAlbumId = album.id },
                            label = { Text(album.name) }
                        )
                    }
                }
            }

            if (visiblePhotos.isEmpty()) {
                EmptyStateView(
                    title = "No Photos Yet",
                    subtitle = "Upload cherished Sher Akbar family memories to this album.",
                    icon = Icons.Outlined.PhotoLibrary,
                    actionLabel = "Upload Photo",
                    onAction = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.weight(1f)
                )
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(visiblePhotos, key = { it.id }) { photo ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(0.88f)
                                .clickable { fullScreenPhoto = photo },
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                PhotoContentImage(photo = photo, modifier = Modifier.fillMaxSize())
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomStart)
                                        .fillMaxWidth()
                                        .background(Color.Black.copy(alpha = 0.62f))
                                        .padding(10.dp)
                                ) {
                                    Column {
                                        Text(
                                            text = photo.caption,
                                            style = MaterialTheme.typography.labelLarge,
                                            color = Color.White,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${photo.eventName} • ${photo.eventDate}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = RoyalGold,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            },
            containerColor = ForestGreen,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        ) {
            Icon(Icons.Outlined.AddAPhoto, contentDescription = "Upload Photo")
        }
    }

    // Create Album Dialog
    if (showCreateAlbumDialog) {
        var name by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var date by remember { mutableStateOf("2026-11-17") }
        AlertDialog(
            onDismissRequest = { showCreateAlbumDialog = false },
            title = { Text("Create Photo Album") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Album Name") }, singleLine = true)
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Description") })
                    OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("Event Date") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.createAlbum(name, desc, date)
                        showCreateAlbumDialog = false
                    },
                    enabled = name.isNotBlank()
                ) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateAlbumDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Upload Photo Metadata Dialog
    pendingPhotoUri?.let { uri ->
        var caption by remember { mutableStateOf("") }
        var eventName by remember { mutableStateOf("Family Gathering") }
        var eventDate by remember { mutableStateOf("2026-11-17") }
        val targetAlbum = selectedAlbumId ?: albums.firstOrNull()?.id ?: "alb_heritage"

        AlertDialog(
            onDismissRequest = { pendingPhotoUri = null },
            title = { Text("Add Photo Details") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = caption, onValueChange = { caption = it }, label = { Text("Caption") })
                    OutlinedTextField(value = eventName, onValueChange = { eventName = it }, label = { Text("Event Name") })
                    OutlinedTextField(value = eventDate, onValueChange = { eventDate = it }, label = { Text("Date") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.uploadPhoto(
                            albumId = targetAlbum,
                            uri = uri,
                            caption = caption.ifBlank { "Sher Akbar Memory" },
                            eventName = eventName,
                            eventDate = eventDate
                        )
                        pendingPhotoUri = null
                    }
                ) { Text("Upload") }
            },
            dismissButton = {
                TextButton(onClick = { pendingPhotoUri = null }) { Text("Cancel") }
            }
        )
    }

    // Full-screen Photo Viewer
    fullScreenPhoto?.let { photo ->
        Dialog(
            onDismissRequest = { fullScreenPhoto = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
            ) {
                PhotoContentImage(
                    photo = photo,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
                Row(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(onClick = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, "Sher Akbar Family Memory: ${photo.caption} (${photo.eventName} - ${photo.eventDate})")
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share Photo"))
                    }) {
                        Icon(Icons.Outlined.Share, contentDescription = "Share", tint = Color.White)
                    }
                    if (isAdmin) {
                        IconButton(onClick = { photoToDelete = photo }) {
                            Icon(Icons.Outlined.Delete, contentDescription = "Delete", tint = CrimsonAlert)
                        }
                    }
                    IconButton(onClick = { fullScreenPhoto = null }) {
                        Icon(Icons.Outlined.Close, contentDescription = "Close", tint = Color.White)
                    }
                }
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.7f))
                        .padding(18.dp)
                ) {
                    Text(photo.caption, style = MaterialTheme.typography.titleMedium, color = Color.White)
                    Text("${photo.eventName} • ${photo.eventDate} • By ${photo.uploadedBy}", style = MaterialTheme.typography.bodyMedium, color = RoyalGold)
                }
            }
        }
    }

    photoToDelete?.let { target ->
        ConfirmDeleteDialog(
            onConfirm = {
                viewModel.deletePhoto(target.id)
                photoToDelete = null
                fullScreenPhoto = null
            },
            onDismiss = { photoToDelete = null }
        )
    }
}

@Composable
private fun PhotoContentImage(
    photo: GalleryPhoto,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop
) {
    val context = LocalContext.current
    val resId = photo.drawableResName?.let {
        context.resources.getIdentifier(it, "drawable", context.packageName)
    } ?: 0
    if (resId != 0) {
        Image(
            painter = painterResource(id = resId),
            contentDescription = photo.caption,
            contentScale = contentScale,
            modifier = modifier
        )
    } else if (!photo.imageUri.isNullOrBlank()) {
        AsyncImage(
            model = photo.imageUri,
            contentDescription = photo.caption,
            contentScale = contentScale,
            modifier = modifier
        )
    }
}
