package com.sherakbar.family.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AddAPhoto
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.SortByAlpha
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sherakbar.family.R
import com.sherakbar.family.data.model.FamilyMember
import com.sherakbar.family.data.model.Gender
import com.sherakbar.family.data.model.MaritalStatus
import com.sherakbar.family.data.model.MemberCategory
import com.sherakbar.family.data.model.MemberSortOrder
import com.sherakbar.family.ui.components.ConfirmDeleteDialog
import com.sherakbar.family.ui.components.EmptyStateView
import com.sherakbar.family.ui.components.GoldOrnamentalDivider
import com.sherakbar.family.ui.components.MemberAvatar
import com.sherakbar.family.ui.theme.CrimsonAlert
import com.sherakbar.family.ui.theme.ForestGreen
import com.sherakbar.family.ui.theme.RoyalGold
import com.sherakbar.family.ui.viewmodel.MainViewModel

@Composable
fun MembersDirectoryScreen(
    viewModel: MainViewModel,
    onOpenMember: (String) -> Unit,
    onAddMember: () -> Unit
) {
    val members by viewModel.filteredMembers.collectAsState()
    val query by viewModel.searchQuery.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val sortOrder by viewModel.sortOrder.collectAsState()
    val isAdmin by viewModel.isAdmin.collectAsState()
    var showSortMenu by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Search & Sort Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Family Members Directory",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Box {
                        IconButton(onClick = { showSortMenu = true }) {
                            Icon(Icons.Outlined.SortByAlpha, contentDescription = "Sort Members")
                        }
                        DropdownMenu(expanded = showSortMenu, onDismissRequest = { showSortMenu = false }) {
                            DropdownMenuItem(
                                text = { Text("Alphabetical (A–Z)") },
                                onClick = { viewModel.updateSortOrder(MemberSortOrder.NAME_ASC); showSortMenu = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Alphabetical (Z–A)") },
                                onClick = { viewModel.updateSortOrder(MemberSortOrder.NAME_DESC); showSortMenu = false }
                            )
                            DropdownMenuItem(
                                text = { Text("By Generation") },
                                onClick = { viewModel.updateSortOrder(MemberSortOrder.GENERATION_ASC); showSortMenu = false }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = query,
                    onValueChange = viewModel::updateSearchQuery,
                    placeholder = { Text(stringResource(R.string.search_members)) },
                    leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                val categoryTabs = listOf(
                    MemberCategory.ALL to "All",
                    MemberCategory.MALE to "Male Members",
                    MemberCategory.FEMALE to "Female Members",
                    MemberCategory.CHILDREN to "Children",
                    MemberCategory.ELDERS to "Elders",
                    MemberCategory.DECEASED to "Deceased"
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(categoryTabs) { (cat, label) ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { viewModel.selectCategory(cat) },
                            label = { Text(label) }
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline)

            if (members.isEmpty()) {
                EmptyStateView(
                    title = "No matching family members",
                    subtitle = "Try adjusting your search query or category filter.",
                    modifier = Modifier.weight(1f)
                )
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(members, key = { it.id }) { member ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenMember(member.id) },
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                MemberAvatar(
                                    fullName = member.fullName,
                                    photoUri = member.photoUri,
                                    drawableResName = member.drawableResName,
                                    size = 54.dp
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = member.fullName,
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    val parentLine = buildString {
                                        if (member.fatherName.isNotBlank()) append("S/O or D/O ${member.fatherName}")
                                        else append("Generation ${member.generation}")
                                        if (member.isDeceased) append(" • Deceased")
                                    }
                                    Text(
                                        text = parentLine,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "Gen ${member.generation} • ${member.address.ifBlank { "Sher Akbar Family" }}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = RoyalGold,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (isAdmin) {
            FloatingActionButton(
                onClick = onAddMember,
                containerColor = ForestGreen,
                contentColor = Color.White,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
            ) {
                Icon(Icons.Outlined.Add, contentDescription = "Add Member")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemberDetailScreen(
    memberId: String,
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onOpenMember: (String) -> Unit,
    onEditMember: (String) -> Unit
) {
    val context = LocalContext.current
    val allMembers by viewModel.allMembers.collectAsState()
    val isAdmin by viewModel.isAdmin.collectAsState()
    val member = allMembers.firstOrNull { it.id == memberId }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    if (member == null) {
        EmptyStateView(
            title = "Member Not Found",
            subtitle = "This family record may have been removed.",
            actionLabel = "Go Back",
            onAction = onBack
        )
        return
    }

    val children = remember(member, allMembers) { viewModel.getChildrenOf(member, allMembers) }
    val siblings = remember(member, allMembers) { viewModel.getSiblingsOf(member, allMembers) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Member Profile", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        val shareText = buildString {
                            append("Sher Akbar Family Profile\n")
                            append("Name: ${member.fullName}\n")
                            if (member.fatherName.isNotBlank()) append("Father: ${member.fatherName}\n")
                            if (member.motherName.isNotBlank()) append("Mother: ${member.motherName}\n")
                            append("Generation: ${member.generation}\n")
                            if (member.biography.isNotBlank()) append("\n${member.biography}")
                        }
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, shareText)
                        }
                        context.startActivity(Intent.createChooser(intent, "Share Family Profile"))
                    }) {
                        Icon(Icons.Outlined.Share, contentDescription = "Share Profile")
                    }
                    if (isAdmin) {
                        IconButton(onClick = { onEditMember(member.id) }) {
                            Icon(Icons.Outlined.Edit, contentDescription = "Edit")
                        }
                        IconButton(onClick = { showDeleteConfirm = true }) {
                            Icon(Icons.Outlined.Delete, contentDescription = "Delete", tint = CrimsonAlert)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ForestGreen,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = RoyalGold
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Profile Header
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, RoyalGold.copy(alpha = 0.55f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    MemberAvatar(
                        fullName = member.fullName,
                        photoUri = member.photoUri,
                        drawableResName = member.drawableResName,
                        size = 96.dp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = member.fullName,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    if (member.fullNameUrdu.isNotBlank()) {
                        Text(
                            text = member.fullNameUrdu,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Generation ${member.generation} • ${member.gender.name} • ${member.maritalStatus.name}",
                        style = MaterialTheme.typography.labelLarge,
                        color = RoyalGold
                    )
                }
            }

            // Biographical Details
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProfileField("Father", member.fatherName.ifBlank { "—" })
                    ProfileField("Mother", member.motherName.ifBlank { "—" })
                    ProfileField("Spouse", member.spouseName.ifBlank { "—" })
                    ProfileField("Date of Birth", member.dateOfBirth.ifBlank { "—" })
                    if (!member.dateOfDeath.isNullOrBlank()) {
                        ProfileField("Date of Passing", member.dateOfDeath)
                    }
                    if (member.contactNumber.isNotBlank()) {
                        ProfileField("Contact", member.contactNumber)
                    }
                    if (member.address.isNotBlank()) {
                        ProfileField("Address", member.address)
                    }
                }
            }

            if (member.biography.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Biography", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(member.biography, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }

            GoldOrnamentalDivider()

            if (children.isNotEmpty()) {
                RelativeChipSection(
                    title = "Children (${children.size})",
                    members = children,
                    onClickMember = onOpenMember
                )
            }

            if (siblings.isNotEmpty()) {
                RelativeChipSection(
                    title = "Brothers & Sisters (${siblings.size})",
                    members = siblings,
                    onClickMember = onOpenMember
                )
            }
        }
    }

    if (showDeleteConfirm) {
        ConfirmDeleteDialog(
            onConfirm = {
                viewModel.deleteMember(member.id)
                showDeleteConfirm = false
                onBack()
            },
            onDismiss = { showDeleteConfirm = false }
        )
    }
}

@Composable
private fun ProfileField(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun RelativeChipSection(
    title: String,
    members: List<FamilyMember>,
    onClickMember: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        members.forEach { rel ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onClickMember(rel.id) },
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    MemberAvatar(
                        fullName = rel.fullName,
                        photoUri = rel.photoUri,
                        drawableResName = rel.drawableResName,
                        size = 40.dp
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(rel.fullName, style = MaterialTheme.typography.labelLarge)
                        Text("Generation ${rel.generation}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemberFormScreen(
    memberId: String?,
    viewModel: MainViewModel,
    onDone: () -> Unit
) {
    val allMembers by viewModel.allMembers.collectAsState()
    val existing = allMembers.firstOrNull { it.id == memberId }

    var fullName by remember { mutableStateOf("") }
    var fullNameUrdu by remember { mutableStateOf("") }
    var fatherName by remember { mutableStateOf("") }
    var motherName by remember { mutableStateOf("") }
    var spouseName by remember { mutableStateOf("") }
    var dob by remember { mutableStateOf("") }
    var dod by remember { mutableStateOf("") }
    var contact by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var biography by remember { mutableStateOf("") }
    var generation by remember { mutableIntStateOf(2) }
    var gender by remember { mutableStateOf(Gender.MALE) }
    var maritalStatus by remember { mutableStateOf(MaritalStatus.SINGLE) }
    var isElder by remember { mutableStateOf(false) }
    var isChild by remember { mutableStateOf(false) }
    var isDeceased by remember { mutableStateOf(false) }
    var pickedPhotoUri by remember { mutableStateOf<Uri?>(null) }

    LaunchedEffect(existing) {
        existing?.let {
            fullName = it.fullName
            fullNameUrdu = it.fullNameUrdu
            fatherName = it.fatherName
            motherName = it.motherName
            spouseName = it.spouseName
            dob = it.dateOfBirth
            dod = it.dateOfDeath.orEmpty()
            contact = it.contactNumber
            address = it.address
            biography = it.biography
            generation = it.generation
            gender = it.gender
            maritalStatus = it.maritalStatus
            isElder = it.isElder
            isChild = it.isChild
            isDeceased = it.isDeceased
        }
    }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) pickedPhotoUri = uri }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (existing == null) "Add Family Member" else "Edit Member") },
                navigationIcon = {
                    IconButton(onClick = onDone) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ForestGreen,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                MemberAvatar(
                    fullName = fullName.ifBlank { "SA" },
                    photoUri = pickedPhotoUri?.toString() ?: existing?.photoUri,
                    drawableResName = existing?.drawableResName,
                    size = 72.dp
                )
                OutlinedButton(
                    onClick = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                ) {
                    Icon(Icons.Outlined.AddAPhoto, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Upload Profile Photo")
                }
            }

            OutlinedTextField(value = fullName, onValueChange = { fullName = it }, label = { Text("Full Name *") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = fullNameUrdu, onValueChange = { fullNameUrdu = it }, label = { Text("Urdu Name (اردو نام)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = fatherName, onValueChange = { fatherName = it }, label = { Text("Father Name") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = motherName, onValueChange = { motherName = it }, label = { Text("Mother Name") }, modifier = Modifier.fillMaxWidth())

            Text("Gender", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Gender.entries.forEach { g ->
                    FilterChip(selected = gender == g, onClick = { gender = g }, label = { Text(g.name) })
                }
            }

            Text("Marital Status", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MaritalStatus.entries.forEach { ms ->
                    FilterChip(selected = maritalStatus == ms, onClick = { maritalStatus = ms }, label = { Text(ms.name) })
                }
            }

            OutlinedTextField(value = spouseName, onValueChange = { spouseName = it }, label = { Text("Spouse Name") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = dob, onValueChange = { dob = it }, label = { Text("Date of Birth (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = dod, onValueChange = { dod = it }, label = { Text("Date of Death (Optional)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = contact, onValueChange = { contact = it }, label = { Text("Contact Number (Optional)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("City / Address") }, modifier = Modifier.fillMaxWidth())

            Text("Family Generation: $generation", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (1..5).forEach { gen ->
                    FilterChip(selected = generation == gen, onClick = { generation = gen }, label = { Text("Gen $gen") })
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = isElder, onCheckedChange = { isElder = it })
                Text("Elder")
                Spacer(modifier = Modifier.width(12.dp))
                Checkbox(checked = isChild, onCheckedChange = { isChild = it })
                Text("Child")
                Spacer(modifier = Modifier.width(12.dp))
                Checkbox(checked = isDeceased, onCheckedChange = { isDeceased = it })
                Text("Deceased")
            }

            OutlinedTextField(
                value = biography,
                onValueChange = { biography = it },
                label = { Text("Short Biography") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    val fatherId = allMembers.firstOrNull { it.fullName.equals(fatherName.trim(), ignoreCase = true) }?.id
                    val motherId = allMembers.firstOrNull { it.fullName.equals(motherName.trim(), ignoreCase = true) }?.id
                    val spouseId = allMembers.firstOrNull { it.fullName.equals(spouseName.trim(), ignoreCase = true) }?.id
                    val record = FamilyMember(
                        id = existing?.id.orEmpty(),
                        fullName = fullName.trim(),
                        fullNameUrdu = fullNameUrdu.trim(),
                        photoUri = existing?.photoUri,
                        drawableResName = existing?.drawableResName,
                        fatherId = fatherId ?: existing?.fatherId,
                        fatherName = fatherName.trim(),
                        motherId = motherId ?: existing?.motherId,
                        motherName = motherName.trim(),
                        gender = gender,
                        dateOfBirth = dob.trim(),
                        dateOfDeath = dod.trim().ifBlank { null },
                        maritalStatus = maritalStatus,
                        spouseId = spouseId ?: existing?.spouseId,
                        spouseName = spouseName.trim(),
                        contactNumber = contact.trim(),
                        address = address.trim(),
                        generation = generation,
                        biography = biography.trim(),
                        isElder = isElder,
                        isChild = isChild,
                        isDeceased = isDeceased || dod.isNotBlank()
                    )
                    viewModel.saveMember(record, pickedPhotoUri)
                    onDone()
                },
                enabled = fullName.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(stringResource(R.string.save))
            }
        }
    }
}
