package com.sherakbar.family.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sherakbar.family.R
import com.sherakbar.family.data.model.Announcement
import com.sherakbar.family.data.model.AnnouncementCategory
import com.sherakbar.family.ui.components.ConfirmDeleteDialog
import com.sherakbar.family.ui.components.EmptyStateView
import com.sherakbar.family.ui.theme.CrimsonAlert
import com.sherakbar.family.ui.theme.ForestGreen
import com.sherakbar.family.ui.theme.RoyalGold
import com.sherakbar.family.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnnouncementsScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val announcements by viewModel.announcements.collectAsState()
    val isAdmin by viewModel.isAdmin.collectAsState()

    var selectedCategory by remember { mutableStateOf<AnnouncementCategory?>(null) }
    var editingAnnouncement by remember { mutableStateOf<Announcement?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<Announcement?>(null) }

    val filtered = remember(announcements, selectedCategory) {
        if (selectedCategory == null) announcements else announcements.filter { it.category == selectedCategory }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.announcements)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ForestGreen,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            if (isAdmin) {
                FloatingActionButton(
                    onClick = { editingAnnouncement = null; showEditor = true },
                    containerColor = ForestGreen,
                    contentColor = Color.White
                ) {
                    Icon(Icons.Outlined.Add, contentDescription = "Publish Announcement")
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedCategory == null,
                        onClick = { selectedCategory = null },
                        label = { Text("All") }
                    )
                }
                items(AnnouncementCategory.entries) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat.name) }
                    )
                }
            }

            if (filtered.isEmpty()) {
                EmptyStateView(
                    title = "No Announcements",
                    subtitle = "Family weddings, births, gatherings, and news will appear here.",
                    icon = Icons.Outlined.Campaign,
                    modifier = Modifier.weight(1f)
                )
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filtered, key = { it.id }) { ann ->
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, if (ann.isPinned) RoyalGold else MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${ann.category.name} • ${ann.eventDate.ifBlank { "Update" }}",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = RoyalGold,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Row {
                                        IconButton(onClick = {
                                            val share = Intent(Intent.ACTION_SEND).apply {
                                                type = "text/plain"
                                                putExtra(Intent.EXTRA_TEXT, "${ann.title}\n\n${ann.content}\n\n— ${ann.authorName} (Sher Akbar Family)")
                                            }
                                            context.startActivity(Intent.createChooser(share, "Share Announcement"))
                                        }) {
                                            Icon(Icons.Outlined.Share, contentDescription = "Share")
                                        }
                                        if (isAdmin) {
                                            IconButton(onClick = { editingAnnouncement = ann; showEditor = true }) {
                                                Icon(Icons.Outlined.Edit, contentDescription = "Edit")
                                            }
                                            IconButton(onClick = { pendingDelete = ann }) {
                                                Icon(Icons.Outlined.Delete, contentDescription = "Delete", tint = CrimsonAlert)
                                            }
                                        }
                                    }
                                }
                                Text(ann.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(ann.content, style = MaterialTheme.typography.bodyLarge)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Posted by ${ann.authorName}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditor) {
        var title by remember { mutableStateOf(editingAnnouncement?.title.orEmpty()) }
        var content by remember { mutableStateOf(editingAnnouncement?.content.orEmpty()) }
        var eventDate by remember { mutableStateOf(editingAnnouncement?.eventDate.orEmpty()) }
        var category by remember { mutableStateOf(editingAnnouncement?.category ?: AnnouncementCategory.NEWS) }
        var isPinned by remember { mutableStateOf(editingAnnouncement?.isPinned ?: false) }

        AlertDialog(
            onDismissRequest = { showEditor = false },
            title = { Text(if (editingAnnouncement == null) "Publish Announcement" else "Edit Announcement") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") })
                    OutlinedTextField(value = content, onValueChange = { content = it }, label = { Text("Message") }, minLines = 3)
                    OutlinedTextField(value = eventDate, onValueChange = { eventDate = it }, label = { Text("Event Date (YYYY-MM-DD)") })
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(AnnouncementCategory.entries) { cat ->
                            FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat.name) })
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isPinned, onCheckedChange = { isPinned = it })
                        Text("Pin to top")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.publishAnnouncement(
                            id = editingAnnouncement?.id,
                            title = title,
                            content = content,
                            category = category,
                            eventDate = eventDate,
                            isPinned = isPinned
                        )
                        showEditor = false
                    },
                    enabled = title.isNotBlank() && content.isNotBlank()
                ) { Text("Publish") }
            },
            dismissButton = {
                TextButton(onClick = { showEditor = false }) { Text("Cancel") }
            }
        )
    }

    pendingDelete?.let { target ->
        ConfirmDeleteDialog(
            onConfirm = {
                viewModel.deleteAnnouncement(target.id)
                pendingDelete = null
            },
            onDismiss = { pendingDelete = null }
        )
    }
}
