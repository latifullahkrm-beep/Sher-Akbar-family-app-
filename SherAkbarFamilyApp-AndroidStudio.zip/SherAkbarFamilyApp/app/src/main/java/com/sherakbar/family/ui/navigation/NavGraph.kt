package com.sherakbar.family.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountTree
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.ui.graphics.vector.ImageVector
import com.sherakbar.family.R

sealed class Screen(val route: String) {
    data object Splash : Screen("splash")
    data object Login : Screen("login")
    data object Register : Screen("register")
    data object Home : Screen("home")
    data object FamilyTree : Screen("family_tree")
    data object Members : Screen("members")
    data object Gallery : Screen("gallery")
    data object More : Screen("more")
    data object MemberDetail : Screen("member_detail/{memberId}") {
        fun createRoute(memberId: String) = "member_detail/$memberId"
    }
    data object MemberForm : Screen("member_form?memberId={memberId}") {
        fun createRoute(memberId: String? = null) =
            if (memberId == null) "member_form" else "member_form?memberId=$memberId"
    }
    data object Announcements : Screen("announcements")
    data object AdminDashboard : Screen("admin_dashboard")
    data object AboutFamily : Screen("about_family")
    data object ContactAdmin : Screen("contact_admin")
    data object Settings : Screen("settings")
}

data class BottomNavItem(
    val route: String,
    val labelRes: Int,
    val icon: ImageVector
)

val bottomNavItems = listOf(
    BottomNavItem(Screen.Home.route, R.string.nav_home, Icons.Outlined.Home),
    BottomNavItem(Screen.FamilyTree.route, R.string.nav_tree, Icons.Outlined.AccountTree),
    BottomNavItem(Screen.Members.route, R.string.nav_members, Icons.Outlined.Groups),
    BottomNavItem(Screen.Gallery.route, R.string.nav_gallery, Icons.Outlined.PhotoLibrary),
    BottomNavItem(Screen.More.route, R.string.nav_more, Icons.Outlined.Menu)
)
