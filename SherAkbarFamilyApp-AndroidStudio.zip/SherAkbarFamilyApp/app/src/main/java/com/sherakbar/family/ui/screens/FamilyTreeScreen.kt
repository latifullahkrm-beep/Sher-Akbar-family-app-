package com.sherakbar.family.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.CenterFocusStrong
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.ZoomIn
import androidx.compose.material.icons.outlined.ZoomOut
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.sherakbar.family.data.model.FamilyMember
import com.sherakbar.family.ui.components.ConfirmDeleteDialog
import com.sherakbar.family.ui.components.EmptyStateView
import com.sherakbar.family.ui.components.MemberAvatar
import com.sherakbar.family.ui.theme.CrimsonAlert
import com.sherakbar.family.ui.theme.ForestGreen
import com.sherakbar.family.ui.theme.RoyalGold
import com.sherakbar.family.ui.viewmodel.MainViewModel
import kotlin.math.roundToInt

@Composable
fun FamilyTreeScreen(
    viewModel: MainViewModel,
    onOpenMember: (String) -> Unit,
    onAddMember: () -> Unit,
    onEditMember: (String) -> Unit
) {
    val members by viewModel.allMembers.collectAsState()
    val isAdmin by viewModel.isAdmin.collectAsState()

    var scale by remember { mutableFloatStateOf(0.85f) }
    var panOffset by remember { mutableStateOf(Offset(40f, 30f)) }
    val collapsedGenerations = remember { mutableStateMapOf<Int, Boolean>() }
    var memberPendingDelete by remember { mutableStateOf<FamilyMember?>(null) }

    val density = LocalDensity.current
    val nodeWidthDp = 158.dp
    val nodeHeightDp = 122.dp
    val hGapDp = 28.dp
    val vGapDp = 78.dp

    val nodeWidthPx = with(density) { nodeWidthDp.toPx() }
    val nodeHeightPx = with(density) { nodeHeightDp.toPx() }
    val hGapPx = with(density) { hGapDp.toPx() }
    val vGapPx = with(density) { vGapDp.toPx() }

    val generations = remember(members) {
        members.groupBy { it.generation }.toSortedMap()
    }

    // Compute (x, y) coordinates for every visible node centered per generation row
    val nodePositions = remember(generations, collapsedGenerations.toMap(), nodeWidthPx, nodeHeightPx, hGapPx, vGapPx) {
        val map = mutableMapOf<String, Offset>()
        val maxRowCount = generations.values.maxOfOrNull { it.size } ?: 1
        val totalCanvasWidth = maxRowCount * (nodeWidthPx + hGapPx)

        var currentY = 64f
        generations.forEach { (gen, list) ->
            val isCollapsed = collapsedGenerations[gen] == true
            if (!isCollapsed) {
                val rowWidth = list.size * nodeWidthPx + (list.size - 1).coerceAtLeast(0) * hGapPx
                val startX = ((totalCanvasWidth - rowWidth) / 2f).coerceAtLeast(32f)
                list.forEachIndexed { idx, member ->
                    val x = startX + idx * (nodeWidthPx + hGapPx)
                    map[member.id] = Offset(x, currentY)
                }
                currentY += nodeHeightPx + vGapPx
            } else {
                currentY += 56f
            }
        }
        map
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (members.isEmpty()) {
            EmptyStateView(
                title = "Family Tree Empty",
                subtitle = "Add the Sher Akbar founders to start building the multi-generation tree.",
                actionLabel = if (isAdmin) "Add Founder" else null,
                onAction = if (isAdmin) onAddMember else null,
                modifier = Modifier.align(Alignment.Center)
            )
        } else {
            // Interactive Pan & Zoom Viewport
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(0.45f, 2.2f)
                            panOffset += pan
                        }
                    }
            ) {
                Box(
                    modifier = Modifier
                        .graphicsLayer(
                            scaleX = scale,
                            scaleY = scale,
                            translationX = panOffset.x,
                            translationY = panOffset.y
                        )
                ) {
                    // Relationship Connector Lines (Parents -> Children, Spouses, Siblings)
                    Canvas(modifier = Modifier.size(2800.dp)) {
                        // Draw spouse connectors (dashed royal gold)
                        val drawnSpouses = mutableSetOf<String>()
                        members.forEach { m ->
                            val spouseId = m.spouseId
                            if (spouseId != null && !drawnSpouses.contains("${spouseId}_${m.id}")) {
                                val p1 = nodePositions[m.id]
                                val p2 = nodePositions[spouseId]
                                if (p1 != null && p2 != null) {
                                    drawnSpouses.add("${m.id}_${spouseId}")
                                    drawLine(
                                        color = RoyalGold,
                                        start = Offset(p1.x + nodeWidthPx / 2f, p1.y + nodeHeightPx / 2f),
                                        end = Offset(p2.x + nodeWidthPx / 2f, p2.y + nodeHeightPx / 2f),
                                        strokeWidth = 3f,
                                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f))
                                    )
                                }
                            }

                            // Draw parent -> child orthogonal connectors (Forest Green)
                            val childPos = nodePositions[m.id] ?: return@forEach
                            val parentId = m.fatherId ?: m.motherId
                            val parentPos = parentId?.let { nodePositions[it] }
                            if (parentPos != null) {
                                val start = Offset(parentPos.x + nodeWidthPx / 2f, parentPos.y + nodeHeightPx)
                                val end = Offset(childPos.x + nodeWidthPx / 2f, childPos.y)
                                val midY = (start.y + end.y) / 2f
                                drawLine(ForestGreen, start, Offset(start.x, midY), strokeWidth = 3.5f)
                                drawLine(ForestGreen, Offset(start.x, midY), Offset(end.x, midY), strokeWidth = 3.5f)
                                drawLine(ForestGreen, Offset(end.x, midY), end, strokeWidth = 3.5f)
                            }
                        }
                    }

                    // Render Member Cards
                    members.forEach { member ->
                        val pos = nodePositions[member.id] ?: return@forEach
                        TreeMemberNode(
                            member = member,
                            isAdmin = isAdmin,
                            modifier = Modifier
                                .offset { IntOffset(pos.x.roundToInt(), pos.y.roundToInt()) }
                                .width(nodeWidthDp)
                                .height(nodeHeightDp),
                            onClick = { onOpenMember(member.id) },
                            onEdit = { onEditMember(member.id) },
                            onDelete = { memberPendingDelete = member }
                        )
                    }
                }
            }
        }

        // Top Bar: Generation Expand/Collapse Strip + Zoom Controls
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Sher Akbar Lineage",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { scale = (scale - 0.15f).coerceAtLeast(0.45f) }) {
                            Icon(Icons.Outlined.ZoomOut, contentDescription = "Zoom Out")
                        }
                        IconButton(onClick = { scale = (scale + 0.15f).coerceAtMost(2.2f) }) {
                            Icon(Icons.Outlined.ZoomIn, contentDescription = "Zoom In")
                        }
                        IconButton(onClick = { scale = 0.85f; panOffset = Offset(40f, 30f) }) {
                            Icon(Icons.Outlined.CenterFocusStrong, contentDescription = "Reset View")
                        }
                    }
                }
            }

            // Expand / Collapse Generation Toggles
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                generations.keys.forEach { gen ->
                    val collapsed = collapsedGenerations[gen] == true
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (collapsed) MaterialTheme.colorScheme.surfaceVariant else ForestGreen,
                        border = BorderStroke(1.dp, RoyalGold.copy(alpha = 0.5f)),
                        modifier = Modifier.clickable { collapsedGenerations[gen] = !collapsed }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Gen $gen",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (collapsed) MaterialTheme.colorScheme.onSurface else Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = if (collapsed) Icons.Outlined.ExpandMore else Icons.Outlined.ExpandLess,
                                contentDescription = null,
                                tint = if (collapsed) MaterialTheme.colorScheme.onSurface else RoyalGold,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        if (isAdmin) {
            FloatingActionButton(
                onClick = onAddMember,
                containerColor = ForestGreen,
                contentColor = Color.White,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
            ) {
                Icon(Icons.Outlined.Add, contentDescription = "Add Member")
            }
        }
    }

    memberPendingDelete?.let { target ->
        ConfirmDeleteDialog(
            onConfirm = {
                viewModel.deleteMember(target.id)
                memberPendingDelete = null
            },
            onDismiss = { memberPendingDelete = null }
        )
    }
}

@Composable
private fun TreeMemberNode(
    member: FamilyMember,
    isAdmin: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (member.generation == 1) 2.dp else 1.dp,
            color = if (member.generation == 1) RoyalGold else ForestGreen.copy(alpha = 0.35f)
        ),
        shadowElevation = 2.dp
    ) {
        Box(modifier = Modifier.fillMaxSize().padding(8.dp)) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                MemberAvatar(
                    fullName = member.fullName,
                    photoUri = member.photoUri,
                    drawableResName = member.drawableResName,
                    size = 44.dp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = member.fullName,
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Gen ${member.generation} • ${member.gender.name.lowercase().replaceFirstChar { it.uppercase() }}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }

            if (isAdmin) {
                Row(modifier = Modifier.align(Alignment.TopEnd)) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .size(22.dp)
                            .clickable(onClick = onEdit)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.Edit, contentDescription = "Edit", modifier = Modifier.size(13.dp))
                        }
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Surface(
                        shape = CircleShape,
                        color = CrimsonAlert.copy(alpha = 0.14f),
                        modifier = Modifier
                            .size(22.dp)
                            .clickable(onClick = onDelete)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.Delete, contentDescription = "Delete", tint = CrimsonAlert, modifier = Modifier.size(13.dp))
                        }
                    }
                }
            }
        }
    }
}
