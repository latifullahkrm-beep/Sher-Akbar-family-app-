package com.sherakbar.family.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sherakbar.family.ui.theme.ForestGreen
import com.sherakbar.family.ui.theme.RoyalGold

@Composable
fun SherAkbarCrest(
    modifier: Modifier = Modifier,
    size: Dp = 64.dp,
    shieldFill: Color = ForestGreen,
    goldColor: Color = RoyalGold
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val cx = w / 2f
        val cy = h / 2f

        // 8-point Rub el Hizb outer frame
        val outerR = w * 0.44f
        val square1 = Path().apply {
            moveTo(cx - outerR * 0.7f, cy - outerR * 0.7f)
            lineTo(cx + outerR * 0.7f, cy - outerR * 0.7f)
            lineTo(cx + outerR * 0.7f, cy + outerR * 0.7f)
            lineTo(cx - outerR * 0.7f, cy + outerR * 0.7f)
            close()
        }
        val diamond = Path().apply {
            moveTo(cx, cy - outerR)
            lineTo(cx + outerR, cy)
            lineTo(cx, cy + outerR)
            lineTo(cx - outerR, cy)
            close()
        }
        drawPath(square1, color = goldColor, style = Stroke(width = w * 0.03f))
        drawPath(diamond, color = goldColor, style = Stroke(width = w * 0.03f))

        // Inner Heritage Shield
        val shield = Path().apply {
            moveTo(cx, h * 0.19f)
            lineTo(w * 0.75f, h * 0.29f)
            lineTo(w * 0.75f, h * 0.54f)
            cubicTo(w * 0.75f, h * 0.69f, cx + w * 0.1f, h * 0.78f, cx, h * 0.84f)
            cubicTo(cx - w * 0.1f, h * 0.78f, w * 0.25f, h * 0.69f, w * 0.25f, h * 0.54f)
            lineTo(w * 0.25f, h * 0.29f)
            close()
        }
        drawPath(shield, color = shieldFill)
        drawPath(shield, color = goldColor, style = Stroke(width = w * 0.032f))

        // Family Tree branches inside shield
        val stroke = w * 0.034f
        drawLine(
            color = goldColor,
            start = Offset(cx, h * 0.72f),
            end = Offset(cx, h * 0.40f),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
        drawLine(
            color = goldColor,
            start = Offset(cx, h * 0.56f),
            end = Offset(w * 0.36f, h * 0.44f),
            strokeWidth = stroke * 0.9f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = goldColor,
            start = Offset(cx, h * 0.56f),
            end = Offset(w * 0.64f, h * 0.44f),
            strokeWidth = stroke * 0.9f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = goldColor,
            start = Offset(cx, h * 0.45f),
            end = Offset(w * 0.42f, h * 0.35f),
            strokeWidth = stroke * 0.8f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = goldColor,
            start = Offset(cx, h * 0.45f),
            end = Offset(w * 0.58f, h * 0.35f),
            strokeWidth = stroke * 0.8f,
            cap = StrokeCap.Round
        )

        // Gold canopy nodes
        drawCircle(goldColor, radius = w * 0.042f, center = Offset(cx, h * 0.31f))
        drawCircle(goldColor, radius = w * 0.035f, center = Offset(w * 0.36f, h * 0.44f))
        drawCircle(goldColor, radius = w * 0.035f, center = Offset(w * 0.64f, h * 0.44f))
        drawCircle(goldColor, radius = w * 0.03f, center = Offset(w * 0.42f, h * 0.35f))
        drawCircle(goldColor, radius = w * 0.03f, center = Offset(w * 0.58f, h * 0.35f))
    }
}
